/* ÉduGestion Pro — service worker : l'application démarre sans réseau. */
const CACHE = 'edugestion-v6.14.0';
const RESSOURCES = [
  './', './index.html', './verification.html', './manifest.webmanifest', './css/app.css',
  './js/schema.js', './js/db.js', './js/rules.js', './js/tableur.js', './js/referentiel-cs.js', './js/seed.js',
  './js/ui.js', './js/qr.js', './js/docs-styles.js', './js/docs-socle.js', './js/docs-modeles.js', './js/sortie.js', './js/screens.js', './js/screens2.js', './js/screens3.js', './js/screens4.js', './js/screens5.js', './js/screens6.js', './js/screens7.js', './js/screens8.js', './js/screens9.js', './js/screens10.js', './js/screens11.js', './js/screens12.js', './js/screens13.js', './js/screens14.js', './js/screens15.js', './js/screens16.js', './js/screens17.js', './js/screens18.js', './js/screens19.js', './js/screens20.js', './js/screens21.js', './js/screens22.js', './js/screens23.js', './js/screens24.js',
  './js/screens25.js', './js/screens26.js', './js/screens27.js', './js/screens28.js', './js/screens29.js', './js/screens30.js', './js/app.js',
  './donnees/paquet-pobe.js', './donnees/paquet-adja-ouere.js', './donnees/paquet-ifangni.js', './donnees/paquet-ketou-1.js', './donnees/paquet-ketou-2.js', './donnees/paquet-sakete.js',
  './assets/entete-memp.jpg', './assets/armoiries-benin.png', './icons/favicon.ico', './icons/icon-180.png', './icons/icon-192.png',
  './icons/icon-512.png', './icons/icon-maskable-192.png', './icons/icon-maskable-512.png'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(RESSOURCES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(cles => Promise.all(cles.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;
  e.respondWith(
    caches.match(e.request).then(reponse => reponse || fetch(e.request)
      .then(r => {
        const copie = r.clone();
        caches.open(CACHE).then(c => c.put(e.request, copie));
        return r;
      })
      .catch(() => caches.match('./index.html')))
  );
});
