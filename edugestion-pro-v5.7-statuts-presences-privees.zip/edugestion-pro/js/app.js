/* ÉduGestion Pro — démarrage, session, droits et navigation. */
(function (global) {
  'use strict';
  const EG = global.EG, DB = EG.DB, U = EG.UI;
  const el = U.el, Routeur = U.Routeur;

  EG.session = null;

  /* ---------------- Droits ---------------- */
  const DROITS = {
    ADMIN_MEMP: { ecrire: true, modules: '*' },
    ADMIN_TECHNIQUE: { ecrire: true, modules: '*' },
    DDEMP: { ecrire: true, modules: '*', sauf: ['securite'] },
    CS: { ecrire: true, modules: '*', sauf: ['securite'] },
    CONSEILLER_PEDAGOGIQUE: {
      ecrire: true, modules: ['eleves', 'inscriptions', 'presences', 'evaluations', 'cep', 'personnel',
        'visites', 'risques', 'alertes', 'analytics', 'rapports', 'documents', 'recensement',
        'reseau', 'telechargements', 'espace-cs', 'unites-pedagogiques', 'repertoire', 'calendrier-scolaire',
        'carte-ecole', 'carte-eleve', 'fiche-cep', 'stats-cs']
    },
    DIRECTEUR: {
      ecrire: true, modules: '*', sauf: ['securite', 'support', 'reseau', 'espace-cs', 'unites-pedagogiques', 'personnel-cs', 'statuts-personnel', 'courriers', 'ecoles-cm2', 'ecarts-cs', 'rapport-rentree']
    },
    ENSEIGNANT: {
      ecrire: true, modules: ['eleves', 'inscriptions', 'presences', 'evaluations', 'cep', 'cantine',
        'risques', 'documents', 'parents', 'educmaster', 'telechargements', 'repertoire', 'calendrier-scolaire',
        'carte-ecole', 'carte-eleve']
    },
    PARENT: { ecrire: false, modules: ['parents'] },
    ELEVE: { ecrire: false, modules: ['parents'] }
  };

  EG.peutEcrire = function () {
    const d = DROITS[EG.session.user.role];
    return !!(d && d.ecrire);
  };
  /* Finances propres aux écoles privées : le directeur d'une école publique ne les voit pas ;
     circonscriptions, directions départementales et administration les consultent. */
  const MODULES_PRIVE = ['scolarite-privee', 'caisse-privee', 'salaires-privee'];
  EG.peutVoirModule = function (code) {
    const d = DROITS[EG.session.user.role];
    if (!d) return false;
    if (d.sauf && d.sauf.indexOf(code) >= 0) return false;
    if (MODULES_PRIVE.indexOf(code) >= 0 && EG.session.user.role === 'DIRECTEUR') return EG.session.ecole_statut === 'PRIVEE';
    if (code === 'carrieres' && EG.session.ecole_statut === 'PRIVEE') return false;   // agents payés par leur école
    return d.modules === '*' || d.modules.indexOf(code) >= 0;
  };

  /* ---------------- Navigation ---------------- */
  const NAV = {
    ENSEIGNANT: [
      ['accueil', '🏠', 'Accueil'], ['presences', '✅', 'Présences'],
      ['evaluations', '📝', 'Notes'], ['cantine', '🍚', 'Cantine'], ['modules', '🧩', 'Modules']
    ],
    DIRECTEUR: [
      ['accueil', '🏠', 'Accueil'], ['eleves', '🎒', 'Élèves'],
      ['patrimoine', '🏫', 'École'], ['alertes', '🔔', 'Alertes'], ['modules', '🧩', 'Modules']
    ],
    PARENT: [
      ['accueil', '🏠', 'Accueil'], ['parents', '👧', 'Mes enfants']
    ],
    ELEVE: [
      ['accueil', '🏠', 'Accueil'], ['parents', '🎒', 'Mon dossier']
    ],
    DEFAUT: [
      ['accueil', '🏠', 'Accueil'], ['gestion-ecoles', '🏫', 'Écoles'], ['analytics', '📊', 'Statistiques'],
      ['alertes', '🔔', 'Alertes'], ['recensement', '🧮', 'Recensement'], ['modules', '🧩', 'Modules']
    ]
  };

  /* ---------------- Authentification ---------------- */
  function ecranConnexion() {
    document.body.className = 'connexion';
    const racine = document.getElementById('app');
    racine.textContent = '';

    const identifiant = el('input', { type: 'text', id: 'id', autocomplete: 'username', required: true, placeholder: 'Votre identifiant' });
    const motdepasse = el('input', { type: 'password', id: 'mdp', autocomplete: 'current-password', required: true });
    const erreur = el('p', { class: 'erreur-connexion' });

    function tenter() {
      erreur.textContent = '';
      const ident = identifiant.value.trim();
      if (!ident || !motdepasse.value) { erreur.textContent = 'Saisissez votre identifiant et votre mot de passe.'; return; }
      DB.where('users', u => u.identifiant === ident && u.actif !== false).then(users => {
        if (!users.length) { erreur.textContent = 'Identifiant inconnu.'; return; }
        const u = users[0];
        return EG.hashMotDePasse(motdepasse.value).then(h => {
          if (h !== u.password_hash) { erreur.textContent = 'Mot de passe incorrect.'; return; }
          return ouvrirSession(u);
        });
      });
    }

    const form = el('form', {
      class: 'carte-connexion', onsubmit: e => { e.preventDefault(); tenter(); }
    }, [
      el('div', { class: 'marque' }, [
        el('span', { class: 'marque-drapeau', 'aria-hidden': 'true' }),
        el('div', {}, [
          el('h1', { text: 'ÉduGestion Pro' }),
          el('p', { text: 'Gestion des écoles maternelles et primaires — Bénin' })
        ])
      ]),
      el('div', { class: 'champ' }, [el('label', { for: 'id', text: 'Identifiant' }), identifiant]),
      el('div', { class: 'champ' }, [el('label', { for: 'mdp', text: 'Mot de passe' }), motdepasse]),
      erreur,
      el('button', { class: 'btn btn-primaire pleine', type: 'submit', text: 'Se connecter' }),
      el('details', { class: 'comptes' }, [
        el('summary', { text: 'Comptes de démonstration' }),
        el('ul', {}, [
          ['admin', 'admin123', 'Administrateur MEMP'],
          ['ddemp.atacora', 'demo123', 'Direction départementale'],
          ['cs.natitingou', 'demo123', 'Circonscription scolaire'],
          ['cp.zone1a', 'demo123', 'Conseiller pédagogique']
        ].map(([i, m, r]) => el('li', {}, el('button', {
          type: 'button', class: 'lien-compte',
          onclick: () => { identifiant.value = i; motdepasse.value = m; tenter(); }
        }, [el('strong', { text: r }), el('span', { class: 'muet petit', text: ' — ' + i })]))))
      ])
    ]);

    racine.appendChild(el('div', { class: 'ecran-connexion' }, form));
    identifiant.focus();
  }

  function ouvrirSession(user) {
    return Promise.all([
      user.ecole_id ? DB.get('ecoles', user.ecole_id) : Promise.resolve(null),
      DB.meta('annee_active').then(id => id ? DB.get('annees_scolaires', id) : null)
    ]).then(([ecole, annee]) => {
      if (!annee) {
        return DB.where('annees_scolaires', { statut: 'OUVERTE' }).then(a => {
          annee = a[0];
          return annee ? DB.setMeta('annee_active', annee.id) : null;
        }).then(() => finaliser(user, ecole, annee));
      }
      return finaliser(user, ecole, annee);
    });
  }

  function finaliser(user, ecole, annee) {
    /* Compte créé ou réinitialisé par l'administration : le mot de passe reçu est
       provisoire, la personne en choisit un à elle avant d'aller plus loin. */
    if (user.doit_changer_mdp) {
      return ecranNouveauMotDePasse(user).then(maj => finaliser(maj, ecole, annee));
    }
    EG.session = {
      user,
      ecole_id: ecole ? ecole.id : null,
      ecole_nom: ecole ? ecole.nom : 'Toutes les écoles',
      ecole_statut: ecole ? ecole.statut || null : null,
      annee_id: annee ? annee.id : null,
      annee_code: annee ? annee.code : '—'
    };
    return DB.setMeta('session_utilisateur', user.id)
      .then(() => DB.audit('CONNEXION', 'users', user.id))
      .then(() => { construireCoquille(); Routeur.aller('accueil'); });
  }

  /** Écran plein cadre : choisir son mot de passe. Rend l'utilisateur mis à jour. */
  function ecranNouveauMotDePasse(user) {
    return new Promise(resolve => {
      document.body.className = 'connexion';
      const racine = document.getElementById('app');
      racine.textContent = '';
      const n1 = el('input', { type: 'password', id: 'nmdp', autocomplete: 'new-password', required: true, minlength: '6' });
      const n2 = el('input', { type: 'password', id: 'nmdp2', autocomplete: 'new-password', required: true });
      const erreur = el('p', { class: 'erreur-connexion' });
      const form = el('form', {
        class: 'carte-connexion', onsubmit: e => {
          e.preventDefault();
          erreur.textContent = '';
          if (n1.value.length < 6) { erreur.textContent = 'Choisissez un mot de passe d’au moins 6 caractères.'; return; }
          if (n1.value !== n2.value) { erreur.textContent = 'Les deux saisies ne sont pas identiques.'; return; }
          EG.hashMotDePasse(n1.value).then(h => {
            if (h === user.password_hash) { erreur.textContent = 'Choisissez un mot de passe différent du mot de passe provisoire.'; return; }
            return DB.put('users', Object.assign({}, user, { password_hash: h, doit_changer_mdp: false }))
              .then(maj => { DB.audit('CHANGEMENT_MDP', 'users', maj.id, {}); EG.majSynchro(); resolve(maj); });
          });
        }
      }, [
        el('div', { class: 'marque' }, [
          el('span', { class: 'marque-drapeau', 'aria-hidden': 'true' }),
          el('div', {}, [el('h1', { text: 'Choisissez votre mot de passe' }), el('p', { text: 'Bienvenue ' + (user.prenoms || user.nom) })])
        ]),
        el('p', { class: 'muet', text: 'Le mot de passe qui vous a été remis est provisoire. Choisissez-en un que vous seul connaissez.' }),
        el('div', { class: 'champ' }, [el('label', { for: 'nmdp', text: 'Nouveau mot de passe' }), n1]),
        el('div', { class: 'champ' }, [el('label', { for: 'nmdp2', text: 'Confirmez le mot de passe' }), n2]),
        erreur,
        el('button', { class: 'btn btn-primaire pleine', type: 'submit', text: 'Enregistrer et continuer' })
      ]);
      racine.appendChild(el('div', { class: 'ecran-connexion' }, form));
      n1.focus();
    });
  }

  function deconnecter() {
    DB.setMeta('session_utilisateur', null).then(() => {
      EG.session = null;
      ecranConnexion();
    });
  }

  /* ---------------- Coquille applicative ----------------
     Deux panneaux : à gauche le tableau des menus, à droite le grand tableau
     (le contenu). Chacun défile pour son compte — la page, elle, ne bouge pas —
     de sorte que faire défiler l'un ne déplace jamais l'autre. Sur téléphone, le
     menu devient un tiroir ouvert par le bouton ☰. */
  function construireCoquille() {
    document.body.className = 'connecte';
    const racine = document.getElementById('app');
    racine.textContent = '';

    const indicateur = el('button', {
      class: 'synchro', id: 'indicateur-synchro', onclick: () => Routeur.aller('sync'),
      'aria-label': 'État de la synchronisation'
    });

    const barre = el('header', { class: 'barre-haut' }, [
      el('button', {
        class: 'icone-btn bouton-menu', id: 'bouton-menu', 'aria-label': 'Ouvrir le menu', 'aria-controls': 'menu-lateral',
        'aria-expanded': 'false', text: '☰', onclick: basculerMenu
      }),
      el('button', {
        class: 'marque-mini', onclick: () => Routeur.aller('accueil'), 'aria-label': 'Accueil'
      }, [el('span', { class: 'marque-drapeau petit-drapeau', 'aria-hidden': 'true' }), el('span', { text: 'ÉduGestion Pro' })]),
      el('div', { class: 'barre-droite' }, [
        indicateur,
        el('button', {
          class: 'icone-btn', 'aria-label': 'Compte et déconnexion', text: '⋯',
          onclick: menuCompte
        })
      ])
    ]);

    const contenu = el('main', { id: 'contenu', tabindex: '-1' });
    const menu = construireMenu();
    const voile = el('div', { class: 'voile-menu', onclick: fermerMenu });

    const items = NAV[EG.session.user.role] || NAV.DEFAUT;
    const nav = el('nav', { class: 'barre-onglets', 'aria-label': 'Navigation principale' },
      items.map(([route, icone, libelle]) => el('button', {
        class: 'onglet', dataset: { route: route.split('/')[0] }, onclick: () => Routeur.aller(route)
      }, [el('span', { class: 'onglet-icone', text: icone, 'aria-hidden': 'true' }), el('span', { text: libelle })])));

    racine.appendChild(el('div', { class: 'coque' }, [
      barre,
      el('div', { class: 'corps-app' }, [menu, voile, contenu]),
      nav
    ]));
    EG.majSynchro();
  }

  /* ---------------- Tableau des menus ---------------- */

  function routeModule(m) { return m.ecran || ('entite/' + m.entites[0]); }

  /** Sous-menu d'un module : ses écrans annexes, puis ses tables. */
  function sousLiens(m) {
    const liens = [];
    const peutImporter = ['ADMIN_MEMP', 'ADMIN_TECHNIQUE', 'DDEMP', 'CS'].indexOf(EG.session.user.role) >= 0 && EG.peutEcrire();
    (m.annexes || []).forEach(([route, lib, icone]) => {
      if (route === 'import-ecoles' && !peutImporter) return; /* réservé à ceux qui peuvent créer des écoles */
      liens.push({ route, lib, icone: icone || '🔗' });
    });
    (m.ecran ? m.entites : m.entites.slice(1)).forEach(e => liens.push({
      route: 'entite/' + e, lib: EG.SCHEMA[e].label, icone: EG.SCHEMA[e].icone || '📄'
    }));
    return liens;
  }

  /* Menu des comptes de circonscription (CS) et de direction départementale (DDEMP) : les rubriques
     de gestion regroupées en trois blocs, chacune menant à son écran. [route, icône, libellé, module (droit)] */
  const MENU_TERRITOIRE_ROLES = ['CS', 'DDEMP'];
  function rubriquesTerritoire() {
    const an = (/(\d{4})\D+(\d{4})/.exec(EG.session.annee_code || '') || [])[2] || '';
    return [
      { nom: 'Menu principal', icone: '📋', coul: '#008751', items: [
        ['accueil', '📊', 'Tableau de bord', null], ['carte-ecole', '🧑‍💼', 'Ma fiche école', 'carte-ecole'],
        ['gestion-ecoles', '🏫', 'Écoles', 'reseau'], ['personnel-cs/enseignants', '👥', 'Personnel enseignant', 'personnel-cs'],
        ['personnel-cs/administratif', '🗂️', 'Personnel administratif', 'personnel-cs'],
        ['statuts-cs/fe', '🧑‍🏫', 'Personnel FE (directeurs, adjoints)', 'statuts-personnel'], ['statuts-cs/acdpe', '🧑‍🏫', 'Personnel ACDPE (directeurs, adjoints)', 'statuts-personnel'],
        ['statuts-cs/prive', '🏫', 'Écoles privées (directeurs, adjoints)', 'statuts-personnel'], ['statuts-cs/acdpctd', '🧑‍🏫', 'Enseignants ACDPCTD', 'statuts-personnel'],
        ['personnel-cs/soutien', '🧹', 'Personnel de soutien', 'personnel-cs'], ['carrieres', '📈', 'Gestion des carrières', 'carrieres'],
        ['visites', '🔎', 'Visites et inspections', 'visites'], ['retraite', '🎓', 'Retraite', 'retraite'],
        ['stats-cs', '👨‍🎓', 'Effectifs élèves', 'stats-cs'], ['entite/infrastructures', '🏗️', 'Infrastructures', 'infrastructure'],
        ['entite/inventaires_mobilier', '🪑', 'Mobilier & matériel', 'mobilier'], ['classes-roles/classes', '🧮', 'Attribution des classes', 'classes-roles'],
        ['classes-roles/roles', '🤝', 'Gestion collégiale', 'classes-roles'], ['repertoire', '📕', 'Répertoires et contacts', 'repertoire']
      ] },
      { nom: 'Gestion pédagogique', icone: '🎒', coul: '#2166AC', items: [
        ['evaluations', '📝', 'Évaluations', 'evaluations'], ['eleves', '🧒', 'Listes des apprenants', 'eleves'],
        ['presences', '🗓️', 'Présence des apprenants', 'presences'], ['presences-personnel', '🕗', 'Présence du personnel', 'presences'],
        ['bulletins', '🗒️', 'Notes et bulletins', 'evaluations'], ['fiche-cep', '📋', 'Inscription CEP', 'fiche-cep'],
        ['ecoles-cm2', '🎯', 'Écoles à CM2 et CEP ' + an, 'ecoles-cm2'], ['cep-blanc-centre', '🏟️', 'Examen blanc', 'cep'],
        ['carte-eleve', '🪪', 'Cartes d’identité', 'carte-eleve']
      ] },
      { nom: 'Administration', icone: '🏛️', coul: '#7B4FA8', items: [
        ['telechargements', '🗂️', 'Fiches officielles', 'telechargements'], ['certificats', '📜', 'Certificats', 'personnel'],
        ['rapport-rentree', '📄', 'Rapports de rentrée', 'rapport-rentree'], ['courriers', '📬', 'Archive courriers', 'courriers'],
        ['ecarts-cs', '📈', 'Analyses et écarts', 'ecarts-cs'], ['cachet', '🔏', 'Cachets et signatures', 'cachets'],
        ['entite/annees_scolaires', '🗓️', 'Années scolaires', 'socle'], ['calendrier-scolaire?type=FERIE&vue=agenda', '📆', 'Jours fériés', 'calendrier-scolaire'],
        ['import-export/import', '📥', 'Import Excel', 'import-export'], ['import-export/sauvegarde', '💾', 'Sauvegarde', 'import-export']
      ] },
      { nom: 'Autres outils', icone: '🧰', coul: '#55616B', replie: true, items: [
        ['espace-cs', '🏢', 'Espace de la circonscription', 'espace-cs'], ['unites-pedagogiques', '🏘️', 'Unités pédagogiques', 'unites-pedagogiques'],
        ['calendrier-scolaire', '🗓️', 'Calendrier scolaire', 'calendrier-scolaire'], ['comptes', '🔑', 'Comptes d’accès', 'comptes'],
        ['statuts-cs/recap', '📊', 'Personnel : récapitulatif par école', 'statuts-personnel'],
        ['scolarite-privee', '🎓', 'Écoles privées : scolarité', 'scolarite-privee'], ['caisse-privee', '📒', 'Écoles privées : cahier des fonds', 'caisse-privee'],
        ['salaires-privee', '👛', 'Écoles privées : salaires', 'salaires-privee'],
        ['import-export/jeux', '🗃️', 'Jeux de données', 'import-export'], ['import-export/personnel', '👥', 'Fichiers du personnel (FE, ACDPE, ACDPCTD)', 'import-export'],
        ['modules', '🧩', 'Tous les modules', null]
      ] }
    ];
  }

  function menuTerritoire(aside, lien) {
    rubriquesTerritoire().forEach(bloc => {
      const items = bloc.items.filter(it => !it[3] || EG.peutVoirModule(it[3]));
      if (!items.length) return;
      const details = el('details', { class: 'menu-categorie', open: !bloc.replie, dataset: { cat: bloc.nom } });
      details.style.setProperty('--coul-cat', bloc.coul);
      details.appendChild(el('summary', {}, [
        el('span', { class: 'menu-icone', text: bloc.icone, 'aria-hidden': 'true' }),
        el('span', { class: 'menu-texte', text: bloc.nom }),
        el('span', { class: 'menu-compte', text: String(items.length) })
      ]));
      items.forEach(([route, icone, lib]) => {
        const l = lien(route, icone, lib, 'principal');
        l.dataset.route = route.split('?')[0];
        details.appendChild(el('div', { class: 'menu-module', dataset: { texte: U.sansAccent(lib) } }, el('div', { class: 'menu-module-tete' }, [l])));
      });
      aside.appendChild(details);
    });
    aside.appendChild(el('p', { class: 'menu-vide muet petit', text: 'Aucune rubrique ne correspond.', hidden: true }));
  }

  function construireMenu() {
    const user = EG.session.user;
    const aside = el('aside', { class: 'menu-lateral', id: 'menu-lateral', 'aria-label': 'Menu principal' });
    const lien = (route, icone, lib, classe) => el('button', {
      class: 'menu-lien ' + (classe || ''), dataset: { route }, onclick: () => Routeur.aller(route)
    }, [el('span', { class: 'menu-icone', text: icone, 'aria-hidden': 'true' }), el('span', { class: 'menu-texte', text: lib })]);

    aside.appendChild(el('div', { class: 'menu-utilisateur' }, [
      el('strong', { text: ((user.prenoms || '') + ' ' + (user.nom || '')).trim() }),
      el('span', { class: 'muet petit', text: U.libelle(user.role) + (EG.session.ecole_id ? ' — ' + EG.session.ecole_nom : '') })
    ]));

    /* Élèves et parents : un menu réduit à l'essentiel. */
    if (user.role === 'PARENT' || user.role === 'ELEVE') {
      (NAV[user.role] || []).forEach(([route, icone, lib]) => aside.appendChild(lien(route, icone, lib)));
      return aside;
    }

    const champ = el('input', {
      type: 'search', class: 'menu-recherche', placeholder: 'Rechercher dans le menu', 'aria-label': 'Rechercher dans le menu',
      autocomplete: 'off', name: 'recherche-menu', value: '',
      oninput: e => filtrerMenu(aside, e.target.value)
    });
    aside.appendChild(champ);
    if (MENU_TERRITOIRE_ROLES.indexOf(user.role) >= 0) { menuTerritoire(aside, lien); return aside; }
    aside.appendChild(lien('accueil', '🏠', 'Accueil', 'menu-accueil'));
    /* La liste complète des modules reste à portée de clic sur ordinateur comme sur téléphone. */
    if (!['PARENT', 'ELEVE'].includes(user.role)) aside.appendChild(lien('modules', '🧩', 'Tous les modules', 'menu-accueil'));

    (EG.CATEGORIES_MODULES || []).forEach(cat => {
      const modules = EG.MODULES.filter(m => m.cat === cat.code && EG.peutVoirModule(m.code));
      if (!modules.length) return;
      const details = el('details', { class: 'menu-categorie', open: true, dataset: { cat: cat.code } });
      details.style.setProperty('--coul-cat', cat.coul);
      details.appendChild(el('summary', {}, [
        el('span', { class: 'menu-icone', text: cat.icone, 'aria-hidden': 'true' }),
        el('span', { class: 'menu-texte', text: cat.nom }),
        el('span', { class: 'menu-compte', text: String(modules.length) })
      ]));
      modules.forEach(m => {
        const subs = sousLiens(m);
        const bloc = el('div', {
          class: 'menu-module', dataset: {
            texte: U.sansAccent([m.nom].concat(subs.map(x => x.lib)).join(' '))
          }
        });
        const tete = el('div', { class: 'menu-module-tete' }, [lien(routeModule(m), m.icone, m.nom, 'principal')]);
        if (subs.length) {
          tete.appendChild(el('button', {
            class: 'menu-deplier', 'aria-label': 'Afficher les rubriques de ' + m.nom, 'aria-expanded': 'false', text: '›',
            onclick: e => {
              const ouvert = bloc.classList.toggle('deplie');
              e.currentTarget.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
            }
          }));
        }
        bloc.appendChild(tete);
        if (subs.length) {
          bloc.appendChild(el('div', { class: 'menu-sous' }, subs.map(x => lien(x.route, x.icone, x.lib, 'sous'))));
        }
        details.appendChild(bloc);
      });
      aside.appendChild(details);
    });
    aside.appendChild(el('p', { class: 'menu-vide muet petit', text: 'Aucune rubrique ne correspond.', hidden: true }));
    return aside;
  }

  function filtrerMenu(aside, saisie) {
    const q = U.sansAccent(saisie).trim();
    let total = 0;
    Array.prototype.forEach.call(aside.querySelectorAll('.menu-categorie'), det => {
      let vus = 0;
      Array.prototype.forEach.call(det.querySelectorAll('.menu-module'), bloc => {
        const ok = !q || bloc.dataset.texte.indexOf(q) >= 0;
        bloc.hidden = !ok;
        if (ok) vus++;
        if (q && ok) bloc.classList.add('deplie'); else if (!q) bloc.classList.remove('deplie');
      });
      det.hidden = !vus;
      total += vus;
      if (q) det.open = vus > 0;
    });
    const vide = aside.querySelector('.menu-vide');
    if (vide) vide.hidden = !q || total > 0;
    if (!q) majMenuActif();
  }

  /** Met en évidence la rubrique en cours et déplie ce qui la contient. */
  function majMenuActif() {
    const menu = document.getElementById('menu-lateral');
    if (!menu) return;
    const chemin = (location.hash || '').replace(/^#\/?/, '').split('?')[0].replace(/\/+$/, '') || 'accueil';
    let meilleur = null, taille = -1;
    Array.prototype.forEach.call(menu.querySelectorAll('.menu-lien'), b => {
      const r = b.dataset.route;
      b.classList.remove('actif');
      if ((chemin === r || chemin.indexOf(r + '/') === 0) && r.length > taille) { meilleur = b; taille = r.length; }
    });
    if (!meilleur) return;
    meilleur.classList.add('actif');
    const bloc = meilleur.closest('.menu-module');
    if (bloc) {
      if (meilleur.classList.contains('sous')) {
        bloc.classList.add('deplie');
        const fleche = bloc.querySelector('.menu-deplier');
        if (fleche) fleche.setAttribute('aria-expanded', 'true');
      }
      const det = bloc.closest('details');
      if (det) det.open = true;
    }
    /* Le menu défile tout seul jusqu'à la rubrique en cours, sans toucher au contenu. */
    const boite = meilleur.getBoundingClientRect(), cadre = menu.getBoundingClientRect();
    if (boite.top < cadre.top + 60 || boite.bottom > cadre.bottom - 20) {
      menu.scrollTop += boite.top - cadre.top - cadre.height / 3;
    }
  }

  EG.majMenu = majMenuActif;

  function basculerMenu() {
    const ouvert = document.body.classList.toggle('menu-ouvert');
    const b = document.getElementById('bouton-menu');
    if (b) b.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
  }
  function fermerMenu() {
    document.body.classList.remove('menu-ouvert');
    const b = document.getElementById('bouton-menu');
    if (b) b.setAttribute('aria-expanded', 'false');
  }

  function menuCompte() {
    const u = EG.session.user;
    U.modal('Mon compte', el('div', {}, [
      el('p', {}, [el('strong', { text: (u.prenoms || '') + ' ' + u.nom }), el('br'), document.createTextNode(U.libelle(u.role))]),
      el('p', { class: 'muet', text: EG.session.ecole_nom + ' • année ' + EG.session.annee_code }),
      el('p', { class: 'muet petit', text: 'ÉduGestion Pro V5.2 — fonctionne hors ligne, les données restent sur cet appareil jusqu’à la synchronisation.' }),
      el('p', { class: 'muet petit', text: u.signature_image ? 'Signature enregistrée : elle est apposée sur les documents que vous éditez.' : 'Aucune signature enregistrée : vos documents porteront un emplacement à signer à la main.' }),
      el('div', { class: 'barre-actions' }, [
        el('button', {
          class: 'btn btn-fantome', text: u.signature_image ? 'Modifier ma signature' : 'Enregistrer ma signature',
          onclick: () => { document.querySelector('.modal-fond').remove(); EG.Docs.capturerSignature(u, null, { table: 'users' }); }
        }),
        el('button', {
          class: 'btn btn-fantome', text: 'Installer l’application',
          onclick: () => { document.querySelector('.modal-fond').remove(); EG.proposerInstallation(); }
        }),
        el('button', { class: 'btn btn-fantome', text: 'Synchronisation', onclick: () => { document.querySelector('.modal-fond').remove(); Routeur.aller('sync'); } }),
        el('button', { class: 'btn btn-fantome', text: 'Tous les modules', onclick: () => { document.querySelector('.modal-fond').remove(); Routeur.aller('modules'); } })
      ])
    ]), fermer => [
      el('button', { class: 'btn btn-fantome', text: 'Fermer', onclick: fermer }),
      el('button', { class: 'btn btn-danger', text: 'Se déconnecter', onclick: () => { fermer(); deconnecter(); } })
    ]);
  }

  EG.majSynchro = function () {
    const n = document.getElementById('indicateur-synchro');
    if (!n) return;
    DB.outboxCount().then(c => {
      if (!navigator.onLine) { n.className = 'synchro hors-ligne'; n.textContent = '⚡ Hors ligne' + (c ? ' · ' + c : ''); }
      else if (c) { n.className = 'synchro attente'; n.textContent = '☁ ' + c + ' en attente'; }
      else { n.className = 'synchro ok'; n.textContent = '✓ À jour'; }
    });
  };

  /* ---------------- Rendu des routes ---------------- */
  function rendre() {
    if (!EG.session) return;
    const { vue, args, params } = Routeur.lire();
    const contenu = document.getElementById('contenu');
    if (!contenu) return;
    contenu.textContent = '';
    contenu.scrollTop = 0;

    Array.prototype.forEach.call(document.querySelectorAll('.onglet'), o => {
      o.classList.toggle('actif', o.dataset.route === vue);
    });
    fermerMenu();
    majMenuActif();

    const rendu = Routeur.routes[vue];
    if (!rendu) { contenu.appendChild(U.vide('Cette page n’existe pas.')); return; }
    try {
      if (EG.Ecrans) EG.Ecrans.dernierEtat = null;
      rendu(contenu, args, params);
      if (EG.LiensImportExport) EG.LiensImportExport.poser(contenu, vue, args, params);
    } catch (e) {
      contenu.appendChild(U.vide('Une erreur est survenue : ' + e.message));
      console.error(e);
    }
    contenu.focus({ preventScroll: true });
  }

  window.addEventListener('hashchange', rendre);
  window.addEventListener('online', EG.majSynchro);
  window.addEventListener('offline', EG.majSynchro);

  /* ---------------- Installation sur l'appareil ----------------
     Le navigateur ne propose l'installation directe que sur une adresse
     sécurisée. Ailleurs, le bandeau reste affiché mais explique la marche à
     suivre plutôt que de disparaître sans rien dire. */
  let promptInstall = null;
  let bandeau = null;

  function dejaInstallee() {
    return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches)
      || window.navigator.standalone === true;
  }

  function surIOS() {
    return /iphone|ipad|ipod/i.test(navigator.userAgent)
      || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  }

  function poserBandeau(texte, action) {
    if (bandeau) bandeau.remove();
    bandeau = el('div', { class: 'bandeau-install' }, [
      el('button', { class: 'bandeau-install-action', text: texte, onclick: action }),
      el('button', {
        class: 'bandeau-install-fermer', text: '✕', 'aria-label': 'Masquer',
        onclick: () => {
          retirerBandeau();
          try { sessionStorage.setItem('install_masque', '1'); } catch (e) { /* sans effet */ }
        }
      })
    ]);
    document.body.appendChild(bandeau);
    /* Le contenu se décale : le bandeau ne doit jamais couvrir une barre d'actions. */
    document.body.classList.add('avec-bandeau');
  }

  function retirerBandeau() {
    if (bandeau) { bandeau.remove(); bandeau = null; }
    document.body.classList.remove('avec-bandeau');
  }

  /** Marche à suivre selon l'appareil, quand le navigateur ne propose rien. */
  function expliquerInstallation() {
    const fichier = location.protocol === 'file:';
    const etapes = fichier
      ? [
        'L’application est ouverte depuis un fichier de votre disque. Les navigateurs '
          + 'réservent l’installation aux adresses sécurisées : il faut donc la mettre en ligne une fois.',
        'Ouvrez app.netlify.com/drop, puis glissez-y le dossier « edugestion-pro » — pas le fichier .zip.',
        'Une adresse en .netlify.app s’affiche après une trentaine de secondes.',
        'Ouvrez cette adresse sur cet appareil : le bandeau d’installation apparaîtra alors.'
      ]
      : surIOS()
        ? [
          'Sur iPhone et iPad, l’installation se fait depuis Safari.',
          'Touchez le bouton Partager, en bas de l’écran.',
          'Choisissez « Sur l’écran d’accueil », puis « Ajouter ».'
        ]
        : [
          'Votre navigateur n’a pas encore proposé l’installation.',
          'Ouvrez son menu — les trois points en haut à droite — puis choisissez '
            + '« Installer l’application » ou « Ajouter à l’écran d’accueil ».',
          'Sur ordinateur, une icône d’installation peut aussi apparaître à droite de la barre d’adresse.'
        ];

    U.modal('Installer ÉduGestion Pro', el('div', {}, [
      el('p', { class: 'muet', text: 'Une fois installée, l’application s’ouvre depuis l’écran '
        + 'd’accueil et fonctionne sans réseau.' }),
      el('ol', { class: 'liste-etapes' }, etapes.map(t => el('li', { text: t })))
    ]), fermer => [el('button', { class: 'btn btn-primaire', text: 'J’ai compris', onclick: fermer })]);
  }

  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    promptInstall = e;
    if (dejaInstallee()) return;
    poserBandeau('📲 Installer ÉduGestion Pro sur cet appareil', () => {
      promptInstall.prompt();
      promptInstall.userChoice.then(() => { retirerBandeau(); promptInstall = null; });
    });
  });

  window.addEventListener('appinstalled', () => {
    retirerBandeau();
    U.toast('ÉduGestion Pro est installée sur cet appareil');
  });

  /* Si le navigateur n'a rien proposé au bout de quelques secondes, le bandeau
     s'affiche quand même et renvoie vers la marche à suivre. */
  function proposerInstallation() {
    if (bandeau || promptInstall || dejaInstallee()) return;
    try { if (sessionStorage.getItem('install_masque')) return; } catch (e) { /* sans effet */ }
    poserBandeau('📲 Installer ÉduGestion Pro — comment faire', expliquerInstallation);
  }
  EG.proposerInstallation = expliquerInstallation;

  /* ---------------- Amorçage ---------------- */
  function demarrer() {
    if ('serviceWorker' in navigator && location.protocol !== 'file:') {
      /* Une nouvelle version prend la main en arrière-plan : la page ouverte affiche encore l'ancienne
         jusqu'au rechargement. On le propose à l'utilisateur plutôt que de le laisser sur l'ancienne. */
      const avaitUnControleur = !!navigator.serviceWorker.controller;
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (!avaitUnControleur || EG.majProposee) return;
        EG.majProposee = true;
        U.modal('Nouvelle version disponible', el('p', { text: 'ÉduGestion Pro a été mis à jour. Actualisez la page pour utiliser la dernière version : vos données sont conservées.' }),
          fermer => [
            el('button', { class: 'btn btn-fantome', text: 'Plus tard', onclick: fermer }),
            el('button', { class: 'btn btn-primaire', text: 'Actualiser maintenant', onclick: () => location.reload() })
          ]);
      });
      navigator.serviceWorker.register('sw.js').catch(() => { /* hors ligne indisponible sans HTTPS */ });
    }
    /* Hauteur réelle de l'écran : sur certains téléphones, 100vh dépasse la zone visible et la barre du bas
       (dont l'onglet « Modules ») passe sous le bord de l'écran. */
    const hauteurEcran = () => document.documentElement.style.setProperty('--hauteur-app', window.innerHeight + 'px');
    hauteurEcran();
    window.addEventListener('resize', hauteurEcran);
    window.addEventListener('orientationchange', () => setTimeout(hauteurEcran, 250));
    /* Une erreur asynchrone dans un écran ne doit jamais laisser la zone de travail vide sans explication. */
    window.addEventListener('unhandledrejection', ev => {
      console.error(ev.reason);
      const c = document.getElementById('contenu');
      if (c && EG.session && !c.querySelector('.etat-vide')) {
        const n = c.children.length;
        if (n <= 1) c.appendChild(U.vide('Cet écran n’a pas pu s’afficher entièrement (' + ((ev.reason && ev.reason.message) || 'erreur inconnue') + '). Retournez à l’accueil puis réessayez.'));
      }
    });
    setTimeout(proposerInstallation, 4000);
    DB.open()
      .then(() => EG.seed())
      .then(() => EG.majMatieres())
      .then(() => EG.majTerritoiresGeographie())
      .then(() => EG.majCirconscriptions())
      .then(() => EG.retirerExemples())
      .then(() => EG.migrerLocalisationEcoles())
      .then(() => EG.migrerRoles())
      .then(() => EG.majProgrammes())
      .then(() => EG.assurerFichesRecensement())
      .then(() => DB.meta('session_utilisateur'))
      .then(id => id ? DB.get('users', id) : null)
      .then(u => (u && u.actif !== false) ? ouvrirSession(u) : ecranConnexion())
      .then(() => rendre())
      .catch(e => {
        console.error(e);
        document.getElementById('app').appendChild(el('div', { class: 'ecran-connexion' },
          el('div', { class: 'carte-connexion' }, [
            el('h1', { text: 'Démarrage impossible' }),
            el('p', { text: 'Le stockage local n’est pas accessible sur cet appareil : ' + e.message }),
            el('p', { class: 'muet petit', text: 'Vérifiez que la navigation privée est désactivée, puis rechargez la page.' })
          ])));
      });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', demarrer);
  else demarrer();
})(window);
